import numpy as np

import torch
import torch.nn as nn
from torch.distributions import Normal
from torch.nn.modules import rnn

class FakeEnv(nn.Module):
    is_recurrent = False
    def __init__(self,  num_actor_obs,
                        num_actions,
                        fake_hidden_dims=[256, 256, 256],
                        activation='elu',
                        init_noise_std=1.0,
                        **kwargs):
        if kwargs:
            print("ActorCritic.__init__ got unexpected arguments, which will be ignored: " + str([key for key in kwargs.keys()]))
        super(FakeEnv, self).__init__()

        activation = get_activation(activation)

        # fake env
        fake_layers = []
        fake_layers.append(nn.Linear(num_actor_obs+num_actions, fake_hidden_dims[0]))
        fake_layers.append(activation)
        for l in range(len(fake_hidden_dims)):
            if l == len(fake_hidden_dims) - 1:
                fake_layers.append(nn.Linear(fake_hidden_dims[l], num_actor_obs + 1 + 1)) # add 1 output for reward
            else:
                fake_layers.append(nn.Linear(fake_hidden_dims[l], fake_hidden_dims[l + 1]))
                fake_layers.append(activation)
        self.fake_env = nn.Sequential(*fake_layers)
        print(f"Fake env MLP: {self.fake_env }")

        # disable args validation for speedup
        Normal.set_default_validate_args = False
        
        # seems that we get better performance without init
        # self.init_memory_weights(self.memory_a, 0.001, 0.)
        # self.init_memory_weights(self.memory_c, 0.001, 0.)

    @staticmethod
    # not used at the moment
    def init_weights(sequential, scales):
        [torch.nn.init.orthogonal_(module.weight, gain=scales[idx]) for idx, module in
         enumerate(mod for mod in sequential if isinstance(mod, nn.Linear))]

    def forward(self, observations, actions):
        # 将状态和动作拼接在一起
        input_tensor = torch.cat([observations, actions], dim=-1)

        # 通过 MLP 进行前向传播
        output = self.fake_env(input_tensor)

        # 拆分输出，得到下一状态和奖励
        next_observations = output[:, :-2]  # 除了最后一列，其余是下一状态
        rewards = output[:, -2:-1].unsqueeze(-1)  # 奖励
        dones = dones = (output[:, -1].unsqueeze(-1) > 0.5).int()   # 结束

        return next_observations, rewards, dones
    

def get_activation(act_name):
    if act_name == "elu":
        return nn.ELU()
    elif act_name == "selu":
        return nn.SELU()
    elif act_name == "relu":
        return nn.ReLU()
    elif act_name == "crelu":
        return nn.ReLU()
    elif act_name == "lrelu":
        return nn.LeakyReLU()
    elif act_name == "tanh":
        return nn.Tanh()
    elif act_name == "sigmoid":
        return nn.Sigmoid()
    else:
        print("invalid activation function!")
        return None
